public class FullName {
    public static void main(String[] args) {
        String myFirstName = "Ievgenia";
        String mySecondName = "Suprunenko";
        String emptyField = " ";
        String myFullName = myFirstName + emptyField + mySecondName;
        System.out.println("My Full Name is " + myFullName);
    }
}
