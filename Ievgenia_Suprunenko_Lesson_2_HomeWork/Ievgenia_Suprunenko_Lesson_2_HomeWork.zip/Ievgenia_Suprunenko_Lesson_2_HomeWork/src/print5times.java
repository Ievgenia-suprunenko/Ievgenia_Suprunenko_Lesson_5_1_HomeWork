public class print5times {
    public static void main(String[] args) {
//        Display message "ITEA IS THE BEST" 5 times
        System.out.println("ITEA IS THE BEST");
        System.out.println("ITEA IS THE BEST");
        System.out.println("ITEA IS THE BEST");
        System.out.println("ITEA IS THE BEST");
        System.out.println("ITEA IS THE BEST");
    }
}
