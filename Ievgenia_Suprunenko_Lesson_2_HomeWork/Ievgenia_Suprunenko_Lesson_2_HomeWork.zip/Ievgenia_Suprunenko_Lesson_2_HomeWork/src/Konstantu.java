public class Konstantu {
    public static void main(String[] args) {
        double miles = 100;
        double KILOMETERS_PER_MILE = 1.609;
        double kilometers = miles * KILOMETERS_PER_MILE;
        System.out.println("kilometers after Step 4 are: " + kilometers);
    }
}
