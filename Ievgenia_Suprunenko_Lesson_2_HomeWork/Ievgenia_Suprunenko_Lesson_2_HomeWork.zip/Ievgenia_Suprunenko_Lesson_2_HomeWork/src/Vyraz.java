public class Vyraz {
    public static void main(String[] args) {
        double X = 2;
        double Y = 2;
        double A = 4;
        double B = 5;
        double C = 10;
        double Result = ((3 + (4 * X)) / 5) - ((10 * (Y - 5) * (A + B + C)) / X) + (9 * ((4 / X) + ((9 + X) / Y)));
        System.out.println("Resultat Vyrazu is: " + Result);
    }
}
