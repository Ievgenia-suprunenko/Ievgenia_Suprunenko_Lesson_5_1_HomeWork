public class Zminni {
    public static void main(String[] args) {
        boolean zminnaBoolean = true;
        System.out.println("zminnaBoolean = " + zminnaBoolean);
        byte zminnaByte = 127;
        System.out.println("zminnaByte = " + zminnaByte);
        short zminnaShort = 2767;
        System.out.println("zminnaShort = " + zminnaShort);
        char zminnaChar = '\u0041';
        System.out.println("zminnaChar = " + zminnaChar);
        int zminnaInt = 2147483647;
        System.out.println("zminnaInt = " + zminnaInt);
        long zminnaLong = 9223372036854775807L;
        System.out.println("zminnaLong = " + zminnaLong);
        float zminnaFloat = 3.25f;
        System.out.println("zminnaFloat = " + zminnaFloat);
        double zminnaDouble = 3.25;
        System.out.println("zminnaDouble = " + zminnaDouble);
    }
}
