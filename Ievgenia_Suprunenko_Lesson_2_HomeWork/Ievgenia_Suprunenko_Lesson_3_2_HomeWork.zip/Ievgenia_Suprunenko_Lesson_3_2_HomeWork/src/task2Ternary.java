public class task2Ternary {
    public static void main(String[] args) {
        String ticketPrice;
        int age = 19;
        ticketPrice = age >= 16 ? "20" : "10";
        System.out.println("Ticket Price is " + ticketPrice);
    }
}
